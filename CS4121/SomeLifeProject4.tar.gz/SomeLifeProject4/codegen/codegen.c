#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <util/string_utils.h>
#include <util/symtab.h>
#include <util/dlink.h>
#include "reg.h"
#include "codegen.h"
#include "symfields.h"
#include "types.h"

extern int globalOffset;

EXTERN(void,SomeLife_error,(char*));

/**
 * Print a data declaration to stdout. This function is called by dlinkApply only.
 *
 * @param decl a DNode containing a data declaration
 */
static void printDataDeclaration(DNode decl) {
	printf("%s\n",(char*)dlinkNodeAtom(decl));
}

/**
 * Print the assembly prologue that includes the data section, a declaration of main and an allocation of stack space
 * for the main routine.
 *
 * @param dataList a list of data declarations (strings and floats)
 * @param frameSize The number of bytes need for local variables declared in main
 */
void emitDataPrologue(DList dataList) {
	
	printf("\t.data\n");
	printf(".newline: .asciiz \"\\n\"\n");
	dlinkApply(dataList,(DLinkApplyFunc)printDataDeclaration);
	printf("\t.text\n");
}

static void saveCalleeSavedRegisters(DList instList) {
	char *inst;
	char offsetStr[10];
	int offset = 4;
	int i;
	for (i = 0; i < CALLER_SAVED_INDEX; i++) { // save $s registers
		sprintf(offsetStr,"%d",offset);
		inst = nssave(5,"\tsw ",getIntegerRegisterName(i),", ",offsetStr,"($fp)");
		dlinkAppend(instList,dlinkNodeAlloc(inst));
		offset += 4;
	}
	for (i = 0; i < FLOAT_CALLER_SAVED_INDEX; i++) { // save $f registers
		sprintf(offsetStr,"%d",offset);
		inst = nssave(5,"\ts.s ",getFloatRegisterName(i),", ",offsetStr,"($fp)");
		dlinkAppend(instList,dlinkNodeAlloc(inst));
		offset += 4;
	}
}

static void saveCallerSavedRegisters(DList instList) {
	char *inst;
	char offsetStr[10];
	int offset = 0;
	int i;
	for (i = CALLER_SAVED_INDEX; i < NUM_INTEGER_REGISTERS; i++) { // save $t registers
		if (isAllocatedIntegerRegister(i)) {
			sprintf(offsetStr,"%d",offset);
			inst = nssave(5,"\tsw ",getIntegerRegisterName(i),", ",offsetStr,"($sp)");
			dlinkAppend(instList,dlinkNodeAlloc(inst));
		}		
		offset += 4;
	}
	for (i = FLOAT_CALLER_SAVED_INDEX; i < NUM_FLOAT_REGISTERS; i++) { // save $f registers
		if (isAllocatedFloatRegister(i)) {
			sprintf(offsetStr,"%d",offset);
			inst = nssave(5,"\ts.s ",getFloatRegisterName(i),", ",offsetStr,"($sp)");
			dlinkAppend(instList,dlinkNodeAlloc(inst));
		}		
		offset += 4;
	}

}

static void restoreCalleeSavedRegisters(DList instList) {
	char *inst;
	char offsetStr[10];
	int offset = 4;
	int i;
	for (i = 0; i < CALLER_SAVED_INDEX; i++) { // restore $t registers
		sprintf(offsetStr,"%d",offset);
		inst = nssave(5,"\tlw ",getIntegerRegisterName(i),", ",offsetStr,"($fp)");
		dlinkAppend(instList,dlinkNodeAlloc(inst));
		offset += 4;
	}
	for (i = 0; i < FLOAT_CALLER_SAVED_INDEX;  i++) { // restore $fp registers
		sprintf(offsetStr,"%d",offset);
		inst = nssave(5,"\tl.s ",getFloatRegisterName(i),", ",offsetStr,"($fp)");
		dlinkAppend(instList,dlinkNodeAlloc(inst));
		offset += 4;
	}
}

static void restoreCallerSavedRegisters(DList instList) {
	char *inst;
	char offsetStr[10];
	int offset = 0;
	int i;
	for (i = CALLER_SAVED_INDEX; i < NUM_INTEGER_REGISTERS; i++) { // restore $t registers
		if (isAllocatedIntegerRegister(i)) {
			sprintf(offsetStr,"%d",offset);
			inst = nssave(5,"\tlw ",getIntegerRegisterName(i),", ",offsetStr,"($sp)");
			dlinkAppend(instList,dlinkNodeAlloc(inst));
		}
		offset += 4;
	}
	for (i = FLOAT_CALLER_SAVED_INDEX; i < NUM_FLOAT_REGISTERS; i++) { // restore $f registers
		if (isAllocatedFloatRegister(i)) {
			sprintf(offsetStr,"%d",offset);
			inst = nssave(5,"\tl.s ",getFloatRegisterName(i),", ",offsetStr,"($sp)");
			dlinkAppend(instList,dlinkNodeAlloc(inst));
		}
		offset += 4;
	}
}

/**
 * Emit the assembly prologue for a procedure
 *
 * @param frameSize The number of bytes need for local variables declared in main
 */
void emitProcedurePrologue(DList instList,SymTable symtab, int index, int frameSize) {

	char *name = (char*)SymGetFieldByIndex(symtab,index,SYM_NAME_FIELD); 

	char* inst = nssave(2,"\t.globl ",name);
	dlinkAppend(instList,dlinkNodeAlloc(inst));
	inst = nssave(2,name,":\tnop");
	dlinkAppend(instList,dlinkNodeAlloc(inst));

	bool isMain = (strcmp(name,"main") == 0);
	char frameStr[10];
	if (!isMain) {
		sprintf(frameStr,"%d",(NUM_CALLEE_SAVED_REGISTERS+NUM_FLOAT_CALLEE_SAVED_REGISTERS+1)*4);
		inst = nssave(2,"\tsub $sp, $sp, ",frameStr);
		dlinkAppend(instList,dlinkNodeAlloc(inst));

		inst = ssave("\tsw\t$fp,($sp)");
		dlinkAppend(instList,dlinkNodeAlloc(inst));
	}

	inst = ssave("\tmove\t$fp,$sp");
	dlinkAppend(instList,dlinkNodeAlloc(inst));

	if (frameSize != 0) {
		sprintf(frameStr,"%d",frameSize);
		inst = nssave(2,"\tadd $sp, $sp, ",frameStr);
		dlinkAppend(instList,dlinkNodeAlloc(inst));
	}

	
	if (!isMain)
		saveCalleeSavedRegisters(instList);
	else
		globalOffset = frameSize;
}

void emitExit(DList instList) {

	char *inst = nssave(2,"\tli $v0, ",SYSCALL_EXIT);
	dlinkAppend(instList,dlinkNodeAlloc(inst));
	inst = ssave("\tsyscall");
	dlinkAppend(instList,dlinkNodeAlloc(inst));
}

/**
 * Emit the procedure epilogue which just uses the exit system call.
 */
void emitProcedureEpilogue(DList instList,int offset) {

	restoreCalleeSavedRegisters(instList);

	char *inst = ssave("\tlw\t$fp,($fp)");
	dlinkAppend(instList,dlinkNodeAlloc(inst));

	char stackSize[20];
	sprintf(stackSize,"%d",(-offset+(NUM_CALLEE_SAVED_REGISTERS+NUM_FLOAT_CALLEE_SAVED_REGISTERS+1)*4));
	inst = nssave(2,"\tadd\t$sp,$sp,",stackSize);
	dlinkAppend(instList,dlinkNodeAlloc(inst));

	inst = ssave("\tjr $ra");
	dlinkAppend(instList,dlinkNodeAlloc(inst));
}

/**
 * Print an assembly instruction to stdout. This function is only called by dlinkApply.
 *
 * @param inst a DNode containing an assembly instruction.
 */
static void printInstruction(DNode inst) {
	printf("%s\n",(char*)dlinkNodeAtom(inst));
}

/**
 * Print all of the assembly instructions for the main routine to stdout.
 *
 * @param instList a DList of assembly instructions.
 */
void emitInstructions(DList instList) {
	
	dlinkApply(instList,(DLinkApplyFunc)printInstruction);
}

/**
 * Convert an integer value to a floating-point value.
 *
 * @param instList a list of instructions
 * @param symtab a symbol table
 * @param regIndex the symbol table index of the register holding the integer value
 * @return the symbol table index of the floating-point register holding the converted value
 */
static int convertIntegerToFloat(DList instList, SymTable symtab, int regIndex) {
	int fpRegIndex = getFreeFloatRegisterIndex(symtab);
	char *fpRegName = SymGetFieldByIndex(symtab,fpRegIndex,SYM_NAME_FIELD);
	char *regName = SymGetFieldByIndex(symtab,regIndex,SYM_NAME_FIELD);
	char *inst = nssave(4,"\tmtc1 ",regName,", ",fpRegName);
	dlinkAppend(instList,dlinkNodeAlloc(inst));

	inst = nssave(4,"\tcvt.s.w ", fpRegName, ", ", fpRegName);
	dlinkAppend(instList,dlinkNodeAlloc(inst));

	freeIntegerRegister((int)SymGetFieldByIndex(symtab,regIndex,SYMTAB_REGISTER_INDEX_FIELD));

	return fpRegIndex;
}

/**
 * Convert a floating-point value to an integer value.
 *
 * @param instList a list of instructions
 * @param symtab a symbol table
 * @param fpRegIndex the symbol table index of the register holding the floating-point value
 * @return the symbol table index of the integer register holding the converted value
 */

static int convertFloatToInteger(DList instList, SymTable symtab, int fpRegIndex) {
	int regIndex = getFreeIntegerRegisterIndex(symtab);
	char *regName = SymGetFieldByIndex(symtab,regIndex,SYM_NAME_FIELD);
	char *fpRegName = SymGetFieldByIndex(symtab,fpRegIndex,SYM_NAME_FIELD);
	
	char *inst = nssave(4,"\tcvt.w.s ", fpRegName, ", ", fpRegName);
	dlinkAppend(instList,dlinkNodeAlloc(inst));
	
	inst = nssave(4,"\tmfc1 ",regName,", ",fpRegName);
	dlinkAppend(instList,dlinkNodeAlloc(inst));

	freeFloatRegister((int)SymGetFieldByIndex(symtab,fpRegIndex,SYMTAB_REGISTER_INDEX_FIELD));

	return regIndex;
}

/**
 * Add an instruction that performance an assignment.
 *
 * @param instList a DList of assembly instructions
 * @param symtab a symbol table
 * @param lhsRegIndex the symbol table index of the register for the l-value address
 * @param rhsRegIndex the symbol table index of the register for the r-value
 */
void emitAssignment(DList instList,SymTable symtab,int lhsRegIndex, int rhsRegIndex) {

	int lhsType = getMemoryTypeByIndex(symtab,lhsRegIndex);
	int rhsType = getTypeByIndex(symtab,rhsRegIndex);

	if (lhsType != rhsType) {
		if (lhsType == INTEGER_TYPE) {
			rhsRegIndex = convertFloatToInteger(instList,symtab,rhsRegIndex);
			rhsType = INTEGER_TYPE;
		}
		else {
			rhsRegIndex = convertIntegerToFloat(instList,symtab,rhsRegIndex);
			rhsType = FLOAT_TYPE;
		}
	}

	char *inst;
	
	if (lhsType == INTEGER_TYPE)
		inst = nssave(5,"\tsw ",
						(char*)SymGetFieldByIndex(symtab,rhsRegIndex,SYM_NAME_FIELD),", 0(",
						(char*)SymGetFieldByIndex(symtab,lhsRegIndex,SYM_NAME_FIELD),")");
	else 
		inst = nssave(5,"\ts.s ",
						(char*)SymGetFieldByIndex(symtab,rhsRegIndex,SYM_NAME_FIELD),", 0(",
						(char*)SymGetFieldByIndex(symtab,lhsRegIndex,SYM_NAME_FIELD),")");
		
	dlinkAppend(instList,dlinkNodeAlloc(inst));

	freeRegisterByType((int)SymGetFieldByIndex(symtab,rhsRegIndex,SYMTAB_REGISTER_INDEX_FIELD),
			rhsType);
	freeIntegerRegister((int)SymGetFieldByIndex(symtab,lhsRegIndex,SYMTAB_REGISTER_INDEX_FIELD));
}

/**
 * Add the instructions needed to read a variable using the read system call.
 *
 * @param instList a DList of instructions
 * @param symtab a symbol table
 * @param addrIndex the symbol table index of the register holding the address that is to be read into
 */
void emitReadVariable(DList instList, SymTable symtab, int addrIndex) {

	int varType = getMemoryTypeByIndex(symtab,addrIndex);

	char* inst;

	if (varType == INTEGER_TYPE)
		inst = nssave(2,"\tli $v0, ", SYSCALL_READ_INTEGER);
	else
		inst = nssave(2,"\tli $v0, ", SYSCALL_READ_FLOAT);

	dlinkAppend(instList,dlinkNodeAlloc(inst));

	inst = ssave("\tsyscall");
	dlinkAppend(instList,dlinkNodeAlloc(inst));

	if (varType == INTEGER_TYPE)
		inst = nssave(3,"\tsw $v0, 0(",
				(char*)SymGetFieldByIndex(symtab,addrIndex,SYM_NAME_FIELD),")");
	else
		inst = nssave(3,"\ts.s $f0, 0(",
				(char*)SymGetFieldByIndex(symtab,addrIndex,SYM_NAME_FIELD),")");

	dlinkAppend(instList,dlinkNodeAlloc(inst));
	freeIntegerRegister((int)SymGetFieldByIndex(symtab,addrIndex,SYMTAB_REGISTER_INDEX_FIELD));

}

/**
 * Add the instructions needed to write a value using the print system call.
 *
 * @param instList a Dlist of instructions
 * @param symtab a symbol table
 * @param regIndex the symbol table index of the register to be printed (must be addres if string)
 * @param syscallService the system call print service to use
 */
void emitWriteExpression(DList instList,SymTable symtab, int regIndex, char* syscallService) {

	int regType = getTypeByIndex(symtab,regIndex);
	
	char *inst;

	if (regType == INTEGER_TYPE)
		inst = nssave(2,"\tmove $a0, ",
			          (char*)SymGetFieldByIndex(symtab,regIndex,SYM_NAME_FIELD));
	else
		inst = nssave(2,"\tmov.s $f12, ",
		          (char*)SymGetFieldByIndex(symtab,regIndex,SYM_NAME_FIELD));
	
	dlinkAppend(instList,dlinkNodeAlloc(inst));
	freeRegisterByType((int)SymGetFieldByIndex(symtab,regIndex,SYMTAB_REGISTER_INDEX_FIELD),
			regType);
	
	inst = nssave(2,"\tli $v0, ",syscallService);
	dlinkAppend(instList,dlinkNodeAlloc(inst));
	
	inst = ssave("\tsyscall");
	dlinkAppend(instList,dlinkNodeAlloc(inst));
	
	inst = nssave(2,"\tli $v0, ",SYSCALL_PRINT_STRING);
	dlinkAppend(instList,dlinkNodeAlloc(inst));
	
	inst = ssave("\tla, $a0, .newline");
	dlinkAppend(instList,dlinkNodeAlloc(inst));
	
	inst = ssave("\tsyscall");
	dlinkAppend(instList,dlinkNodeAlloc(inst));
	
}

/**
 * Create a unique label
 * @param label a character array of size 20 in which the label will be stored
 */
static void makeLabel(char label[20]) {
	static int labelCount = 0;

	snprintf(label,19,".L%d",labelCount++);
}

/**
 * Insert instructions to test whether the expression of a if-statement is false, if false, branch around the then-part
 * of the if-statement.
 *
 * @param instList a list of instructions
 * @param symtab a symbol table
 * @param regIndex the symbol table index of the register holding the rest of the test expression of an if-statement
 * @return the symbol table index of the label that must follow the then-part of an if-statement
 */
int emitIfTest(DList instList, SymTable symtab, int regIndex) {
	char label[20];
	makeLabel(label);

	if (getTypeByIndex(symtab,regIndex) == FLOAT_TYPE)
		regIndex = convertFloatToInteger(instList,symtab,regIndex);

	char* inst = nssave(4,"\tbeq ",SymGetFieldByIndex(symtab,regIndex,SYM_NAME_FIELD),", $zero, ",label);

	dlinkAppend(instList,dlinkNodeAlloc(inst));

	freeIntegerRegister((int)SymGetFieldByIndex(symtab,regIndex,SYMTAB_REGISTER_INDEX_FIELD));

	return SymIndex(symtab,label);
}
/**
 * Insert a nop as a branch target in the list of instructions.
 *
 * @param instList a list of instructions
 * @param symtab a symbol table
 * @param endLabelIndex the symbol table index of the label for the nop
 */
void emitEndBranchTarget(DList instList, SymTable symtab, int endLabelIndex) {
	char* inst = nssave(2,SymGetFieldByIndex(symtab,endLabelIndex,SYM_NAME_FIELD),":\t nop");

	dlinkAppend(instList, dlinkNodeAlloc(inst));
}

/**
 * Insert a branch to an ending label after the else-part of an if-statement.
 *
 * @param instList a list of instructions
 * @param symtab a symbol table
 * @param elseLabelIndex the symbol table index of the label for the beginning of the else-part of an if-statement
 * @return a symbol table index for the end label of an if-statement
 */
int emitThenBranch(DList instList, SymTable symtab, int elseLabelIndex) {
	char label[20];
	makeLabel(label);

	char* inst = nssave(2,"\tj ",label);

	dlinkAppend(instList, dlinkNodeAlloc(inst));

	emitEndBranchTarget(instList,symtab,elseLabelIndex);

	return SymIndex(symtab,label);
}
/**
 * Insert a nop to serve as a target of the backwards branch of a while-statement
 *
 * @param instList a list of instructions
 * @param symtab a symbol table
 * @return the label for the backwards branch target
 */
int emitWhileLoopLandingPad(DList instList,SymTable symtab) {
	char label[20];
	makeLabel(label);

	char *inst = nssave(2,label,":\tnop");

	dlinkAppend(instList,dlinkNodeAlloc(inst));

	return SymIndex(symtab,label);
}

/**
 * Insert a test to enter a while loop. If the test is false, branch to a label after the loop.
 *
 * @param instList a list of instructions
 * @param symtab a symbol table
 * @param regIndex a symbol table index for the register holding the result of the test expression of a while-statement
 * @return a symbol table index for the label at the end of the while-loop
 */
int emitWhileLoopTest(DList instList, SymTable symtab, int regIndex) {
	char label[20];
	makeLabel(label);

	if (getTypeByIndex(symtab,regIndex) == FLOAT_TYPE)
		regIndex = convertFloatToInteger(instList,symtab,regIndex);

	char* inst = nssave(4,"\tbeq ",(char*)SymGetFieldByIndex(symtab,regIndex,SYM_NAME_FIELD),", $zero, ",label);

	dlinkAppend(instList,dlinkNodeAlloc(inst));

	freeIntegerRegister((int)SymGetFieldByIndex(symtab,regIndex,SYMTAB_REGISTER_INDEX_FIELD));

	return SymIndex(symtab,label);
}

/**
 * Insert a branch back to the the landing pad of a while loop, followed by a branch target for loop exit.
 *
 * @param instList a list of instructions
 * @param symtab a symbol table
 * @param beginLabelIndex a symbol table index of the label for the while loop landing pad
 * @param endLabelIndex a symbol table index of the lable for the exit of the while loop
 */
void emitWhileLoopBackBranch(DList instList, SymTable symtab, int beginLabelIndex, int endLabelIndex) {
	char *inst = nssave(2,"\tj ",(char*)SymGetFieldByIndex(symtab,beginLabelIndex,SYM_NAME_FIELD));

	dlinkAppend(instList,dlinkNodeAlloc(inst));

	inst = nssave(2,(char*)SymGetFieldByIndex(symtab,endLabelIndex,SYM_NAME_FIELD),":\t nop");

	dlinkAppend(instList,dlinkNodeAlloc(inst));
}

/**
 * Add a return instruction.
 *
 * @param instList a DList of instructions
 */
void emitReturn(DList instList, SymTable symtab, int exprIndex, int functionType, int localSize) {


	int exprType = getTypeByIndex(symtab,exprIndex);

	if (functionType != exprType) {
		if (functionType == INTEGER_TYPE) {
			exprIndex = convertFloatToInteger(instList,symtab,exprIndex);
			exprType = INTEGER_TYPE;
		}
		else {
			exprIndex = convertIntegerToFloat(instList,symtab,exprIndex);
			exprType = FLOAT_TYPE;
		}
	}

	char *inst;

	if (functionType == INTEGER_TYPE)
		inst = nssave(2,"\tmove $v0, ",(char*)SymGetFieldByIndex(symtab,exprIndex,SYM_NAME_FIELD));
	else 
		inst = nssave(2,"\tmov.s $f0, ",(char*)SymGetFieldByIndex(symtab,exprIndex,SYM_NAME_FIELD));
	dlinkAppend(instList,dlinkNodeAlloc(inst));

	emitProcedureEpilogue(instList,localSize);
}

/**
 * Add an instruction that performs a binary computation.
 *
 * @param instList a DList of instructions
 * @param symtab a symbol table
 * @param typeTable the type table for the expression being emitted
 * @param leftOperand the symbol table index of the register holding the left operand
 * @param rightOperand the symbol table index of the register holding the right operand
 * @param opcode the opcode of the mips assembly instruction
 * @return
 */
static int emitBinaryExpression(DList instList, SymTable symtab, int leftOperand, int rightOperand, char* opcode) {

	int resultType = getTypeByIndex(symtab,leftOperand);

	int regIndex;

	if (resultType == INTEGER_TYPE)
		regIndex = getFreeIntegerRegisterIndex(symtab);
	else
		regIndex = getFreeFloatRegisterIndex(symtab);

	char* regName = (char*)SymGetFieldByIndex(symtab,regIndex,SYM_NAME_FIELD);
	char* leftName = (char*)SymGetFieldByIndex(symtab,leftOperand,SYM_NAME_FIELD);
	char* rightName = (char*)SymGetFieldByIndex(symtab,rightOperand,SYM_NAME_FIELD);

	char* inst = nssave(8,"\t",opcode," ",regName,", ",leftName,", ",rightName);
	dlinkAppend(instList,dlinkNodeAlloc(inst));

	freeRegisterByType((int)SymGetFieldByIndex(symtab,leftOperand,SYMTAB_REGISTER_INDEX_FIELD),
		getTypeByIndex(symtab,leftOperand));
	freeRegisterByType((int)SymGetFieldByIndex(symtab,rightOperand,SYMTAB_REGISTER_INDEX_FIELD),
		getTypeByIndex(symtab,rightOperand));

	return regIndex;
}
/**
 * Convert operands to a logic operation to integers if necessary. The operands are
 * pointers so that they can change as needed.
 *
 * @param instList a list of instructions
 * @param symtab a symbol table
 * @param leftOperand a point to the symbol table index for the left operand
 * @param rightOperand a point to the symbol table index for the right operand
 */
static void performLogicTypeConversion(DList instList, SymTable symtab, int *leftOperand,
		int *rightOperand) {
	int leftType = getTypeByIndex(symtab,*leftOperand);

	if (leftType == FLOAT_TYPE)
		*leftOperand =  convertFloatToInteger(instList,symtab,*leftOperand);

	if (rightOperand != NULL) {
		int rightType = getTypeByIndex(symtab,*rightOperand);

		if (rightType == FLOAT_TYPE)
			*rightOperand = convertFloatToInteger(instList,symtab,*rightOperand);
	}
}

/**
 * Add an or instruction.
 *
 * @param instList a DList of instructions
 * @param symtab a symbol table
 * @param leftOperand the symbol table index of the register holding the left operand
 * @param rightOperand the symbol table index of the register holding the right operand
 * @return the symbol table index for the result register
 */
int emitOrExpression(DList instList, SymTable symtab, int leftOperand, int rightOperand) {
	performLogicTypeConversion(instList, symtab, &leftOperand, &rightOperand);
	return emitBinaryExpression(instList,symtab,leftOperand,rightOperand,"or");
}

/**
 * Add an and instruction.
 *
 * @param instList a DList of instructions
 * @param symtab a symbol table
 * @param leftOperand the symbol table index of the register holding the left operand
 * @param rightOperand the symbol table index of the register holding the right operand
 * @return the symbol table index for the result register
 */
int emitAndExpression(DList instList, SymTable symtab, int leftOperand, int rightOperand) {
	performLogicTypeConversion(instList, symtab, &leftOperand, &rightOperand);
	return emitBinaryExpression(instList,symtab,leftOperand,rightOperand,"and");
}

/**
 * Add a not instruction.
 *
 * @param instList a DList of instructions
 * @param symtab a symbol table
 * @param operand the symbol table index of the register holding the operand
 * @return the symbol table index for the result register
 */
int emitNotExpression(DList instList, SymTable symtab, int operand) {
	performLogicTypeConversion(instList,symtab,&operand,NULL);
	int regIndex = getFreeIntegerRegisterIndex(symtab);
	char* regName = (char*)SymGetFieldByIndex(symtab,regIndex,SYM_NAME_FIELD);
	char* opName = (char*)SymGetFieldByIndex(symtab,operand,SYM_NAME_FIELD);

	char* inst = nssave(5,"\txori ",regName,", ",opName,", 1");
	dlinkAppend(instList,dlinkNodeAlloc(inst));

	freeIntegerRegister((int)SymGetFieldByIndex(symtab,operand,SYMTAB_REGISTER_INDEX_FIELD));

	return regIndex;
}
/**
 * Convert the operands of a comparison to be the same type if necessary. The operands
 * are passed as pointers so that they can change.
 *
 * @param instList a list of instructions
 * @param symtab a symbol table
 * @param leftOperand a pointer to the symbol table index of the left operand
 * @param rightOperand a pointer to the symbol table index of the right operand
 */
static void performComparisonTypeConversion(DList instList, SymTable symtab, int *leftOperand,
		int *rightOperand) {
	int leftType = getTypeByIndex(symtab,*leftOperand);
	int rightType = getTypeByIndex(symtab,*rightOperand);

	if (leftType != rightType) {
		if (leftType == FLOAT_TYPE)
			*rightOperand = convertIntegerToFloat(instList,symtab,*rightOperand);
		else
			*leftOperand = convertIntegerToFloat(instList,symtab,*leftOperand);
	}
}

/**
 * Emit the mips instruction necessary to perform a floating-point compare.
 *
 * @param instList a list of instructions
 * @param symtab a symbol table
 * @param leftOperand the symbol table index of the left operand
 * @param rightOperand the symbol table index of the right operand
 * @param opCode the comparison opcode
 * @param movCode the opcode for moving based on condition code, either "movt" or "movf"
 * @return the symbol table index of the register holding the result value
 */
static int emitFloatCompare(DList instList, SymTable symtab, int leftOperand,
		int rightOperand, char* opCode, char* movCode) {
	char* inst = nssave(6,"\t",opCode," ",
			SymGetFieldByIndex(symtab,leftOperand,SYM_NAME_FIELD),
			", ", SymGetFieldByIndex(symtab,rightOperand,SYM_NAME_FIELD));
	dlinkAppend(instList,dlinkNodeAlloc(inst));

	int resultReg = getFreeIntegerRegisterIndex(symtab);
	char *resultName = SymGetFieldByIndex(symtab,resultReg,SYM_NAME_FIELD);
	inst = nssave(3,"\tli ",resultName,", 0");
	dlinkAppend(instList,dlinkNodeAlloc(inst));

	int tempReg = getFreeIntegerRegisterIndex(symtab);
	char *tempName = SymGetFieldByIndex(symtab,tempReg,SYM_NAME_FIELD);
	inst = nssave(3,"\tli ",tempName,", 1");
	dlinkAppend(instList,dlinkNodeAlloc(inst));

	inst = nssave(6,"\t",movCode," ",resultName,", ",tempName);
	dlinkAppend(instList,dlinkNodeAlloc(inst));

	freeIntegerRegister((int)SymGetFieldByIndex(symtab,tempReg,SYMTAB_REGISTER_INDEX_FIELD));
	freeFloatRegister((int)SymGetFieldByIndex(symtab,leftOperand,SYMTAB_REGISTER_INDEX_FIELD));
	freeFloatRegister((int)SymGetFieldByIndex(symtab,rightOperand,SYMTAB_REGISTER_INDEX_FIELD));

	return resultReg;
}

/**
 * Add an equal instruction.
 *
 * @param instList a DList of instructions
 * @param symtab a symbol table
 * @param leftOperand the symbol table index of the register holding the left operand
 * @param rightOperand the symbol table index of the register holding the right operand
 * @return the symbol table index for the result register
 */
int emitEqualExpression(DList instList, SymTable symtab, int leftOperand, int rightOperand) {
	performComparisonTypeConversion(instList, symtab, &leftOperand, &rightOperand);

	if (getTypeByIndex(symtab,leftOperand) == INTEGER_TYPE)
		return emitBinaryExpression(instList,symtab,leftOperand,rightOperand,"seq");
	else
		return emitFloatCompare(instList,symtab,leftOperand,rightOperand,"c.eq.s","movt");
}
/**
 * Add a not-equal instruction.
 *
 * @param instList a DList of instructions
 * @param symtab a symbol table
 * @param leftOperand the symbol table index of the register holding the left operand
 * @param rightOperand the symbol table index of the register holding the right operand
 * @return the symbol table index for the result register
 */

int emitNotEqualExpression(DList instList, SymTable symtab, int leftOperand, int rightOperand) {
	performComparisonTypeConversion(instList, symtab, &leftOperand, &rightOperand);

	if (getTypeByIndex(symtab,leftOperand) == INTEGER_TYPE)
		return emitBinaryExpression(instList,symtab,leftOperand,rightOperand,"sne");
	else
		return emitFloatCompare(instList,symtab,leftOperand,rightOperand,"c.eq.s","movf");
}

/**
 * Add an less-or-equal instruction.
 *
 * @param instList a DList of instructions
 * @param symtab a symbol table
 * @param leftOperand the symbol table index of the register holding the left operand
 * @param rightOperand the symbol table index of the register holding the right operand
 * @return the symbol table index for the result register
 */
int emitLessEqualExpression(DList instList, SymTable symtab, int leftOperand, int rightOperand) {
	performComparisonTypeConversion(instList, symtab, &leftOperand, &rightOperand);

	if (getTypeByIndex(symtab,leftOperand) == INTEGER_TYPE)
		return emitBinaryExpression(instList,symtab,leftOperand,rightOperand,"sle");
	else
		return emitFloatCompare(instList,symtab,leftOperand,rightOperand,"c.le.s","movt");
}

/**
 * Add a less-than instruction.
 *
 * @param instList a DList of instructions
 * @param symtab a symbol table
 * @param leftOperand the symbol table index of the register holding the left operand
 * @param rightOperand the symbol table index of the register holding the right operand
 * @return the symbol table index for the result register
 */
int emitLessThanExpression(DList instList, SymTable symtab, int leftOperand, int rightOperand) {
	performComparisonTypeConversion(instList, symtab, &leftOperand, &rightOperand);

	if (getTypeByIndex(symtab,leftOperand) == INTEGER_TYPE)
		return emitBinaryExpression(instList,symtab,leftOperand,rightOperand,"slt");
	else
		return emitFloatCompare(instList,symtab,leftOperand,rightOperand,"c.lt.s","movt");
}

/**
 * Add a greater-equal instruction.
 *
 * @param instList a DList of instructions
 * @param symtab a symbol table
 * @param leftOperand the symbol table index of the register holding the left operand
 * @param rightOperand the symbol table index of the register holding the right operand
 * @return the symbol table index for the result register
 */
int emitGreaterEqualExpression(DList instList, SymTable symtab, int leftOperand, int rightOperand) {
	performComparisonTypeConversion(instList, symtab, &leftOperand, &rightOperand);

	if (getTypeByIndex(symtab,leftOperand) == INTEGER_TYPE)
		return emitBinaryExpression(instList,symtab,leftOperand,rightOperand,"sge");
	else
		return emitFloatCompare(instList,symtab,rightOperand,leftOperand,"c.le.s","movt");
}

/**
 * Add a greater-than instruction.
 *
 * @param instList a DList of instructions
 * @param symtab a symbol table
 * @param leftOperand the symbol table index of the register holding the left operand
 * @param rightOperand the symbol table index of the register holding the right operand
 * @return the symbol table index for the result register
 */
int emitGreaterThanExpression(DList instList, SymTable symtab, int leftOperand, int rightOperand) {
	performComparisonTypeConversion(instList, symtab, &leftOperand, &rightOperand);

	if (getTypeByIndex(symtab,leftOperand) == INTEGER_TYPE)
		return emitBinaryExpression(instList,symtab,leftOperand,rightOperand,"sgt");
	else
		return emitFloatCompare(instList,symtab,rightOperand,leftOperand,"c.lt.s","movt");
}

/**
 * Convert the operands in an arithmetic operation to the same type. The operands are
 * passed as pointers to symbol table indices to allow them to change if necessary.
 *
 * @param instList a list of instructions
 * @param symtab a symbol table
 * @param leftOperand a pointer to the symbol table index of the left operand
 * @param rightOperand a pointer to the symbol table index of the right operand
 */
static void performArithmeticTypeConversion(DList instList, SymTable symtab, int *leftOperand,
		int *rightOperand) {
	int leftType = getTypeByIndex(symtab,*leftOperand);
	int rightType = getTypeByIndex(symtab,*rightOperand);

	if (leftType != rightType) {
		if (leftType == FLOAT_TYPE && rightType == INTEGER_TYPE)
			*rightOperand = convertIntegerToFloat(instList,symtab,*rightOperand);
		else if (leftType == INTEGER_TYPE && rightType == FLOAT_TYPE)
			*leftOperand = convertIntegerToFloat(instList,symtab,*leftOperand);
	}
}

/**
 * Add an add instruction.
 *
 * @param instList a DList of instructions
 * @param symtab a symbol table
 * @param leftOperand the symbol table index of the register holding the left operand
 * @param rightOperand the symbol table index of the register holding the right operand
 * @return the symbol table index for the result register
 */
int emitAddExpression(DList instList, SymTable symtab, int leftOperand, int rightOperand) {
	performArithmeticTypeConversion(instList,symtab,&leftOperand,&rightOperand);
	if (getTypeByIndex(symtab,leftOperand) == INTEGER_TYPE)
		return emitBinaryExpression(instList,symtab,leftOperand,rightOperand,"add");
	else
		return emitBinaryExpression(instList,symtab,leftOperand,rightOperand,"add.s");

}

/**
 * Add a subtract instruction.
 *
 * @param instList a DList of instructions
 * @param symtab a symbol table
 * @param leftOperand the symbol table index of the register holding the left operand
 * @param rightOperand the symbol table index of the register holding the right operand
 * @return the symbol table index for the result register
 */
int emitSubtractExpression(DList instList, SymTable symtab, int leftOperand, int rightOperand) {
	performArithmeticTypeConversion(instList,symtab,&leftOperand,&rightOperand);
	if (getTypeByIndex(symtab,leftOperand) == INTEGER_TYPE)
		return emitBinaryExpression(instList,symtab,leftOperand,rightOperand,"sub");
	else
		return emitBinaryExpression(instList,symtab,leftOperand,rightOperand,"sub.s");
}

/**
 * Add a multiply instruction.
 *
 * @param instList a DList of instructions
 * @param symtab a symbol table
 * @param leftOperand the symbol table index of the register holding the left operand
 * @param rightOperand the symbol table index of the register holding the right operand
 * @return the symbol table index for the result register
 */
int emitMultiplyExpression(DList instList, SymTable symtab, int leftOperand, int rightOperand) {
	performArithmeticTypeConversion(instList,symtab,&leftOperand,&rightOperand);
	if (getTypeByIndex(symtab,leftOperand) == INTEGER_TYPE)
		return emitBinaryExpression(instList,symtab,leftOperand,rightOperand,"mul");
	else
		return emitBinaryExpression(instList,symtab,leftOperand,rightOperand,"mul.s");
}

/**
 * Add a divide instruction.
 *
 * @param instList a DList of instructions
 * @param symtab a symbol table
 * @param leftOperand the symbol table index of the register holding the left operand
 * @param rightOperand the symbol table index of the register holding the right operand
 * @return the symbol table index for the result register
 */
int emitDivideExpression(DList instList, SymTable symtab, int leftOperand, int rightOperand) {
	performArithmeticTypeConversion(instList,symtab,&leftOperand,&rightOperand);
	if (getTypeByIndex(symtab,leftOperand) == INTEGER_TYPE)
		return emitBinaryExpression(instList,symtab,leftOperand,rightOperand,"div");
	else
		return emitBinaryExpression(instList,symtab,leftOperand,rightOperand,"div.s");
}

/**
 * Add a function call instruction.
 *
 * @param instList a DList of instructions
 * @param func name of function to call
 * @return the type of the result on the top of the stack
 */
int emitFunctionCall(DList instList, SymTable symtab, char* func, int dataType) {
	char *inst = ssave("\tadd $sp, $sp, -76 "); // make space for $t, $fp registers and $ra
	dlinkAppend(instList,dlinkNodeAlloc(inst));

	saveCallerSavedRegisters(instList);

	inst = ssave("\tsw $ra, 72($sp)");
	dlinkAppend(instList,dlinkNodeAlloc(inst));
	inst = nssave(2,"\tjal ",func);
	dlinkAppend(instList,dlinkNodeAlloc(inst));

	restoreCallerSavedRegisters(instList);

	inst = ssave("\tlw $ra, 72($sp)");
	dlinkAppend(instList,dlinkNodeAlloc(inst));
	inst = ssave("\tadd $sp, $sp, 76 "); // remove space for registers
	dlinkAppend(instList,dlinkNodeAlloc(inst));

	int regIndex;
	char *regName;
	if (dataType == INTEGER_TYPE) {
		regIndex = getFreeIntegerRegisterIndex(symtab);
		regName = (char*)SymGetFieldByIndex(symtab,regIndex,SYM_NAME_FIELD);
	  	inst = nssave(3,"\tmove ",regName,", $v0");
	}
	else {
		regIndex = getFreeFloatRegisterIndex(symtab);
		regName = (char*)SymGetFieldByIndex(symtab,regIndex,SYM_NAME_FIELD);
	  	inst = nssave(3,"\tmov.s ",regName,", $f0");
	}
	dlinkAppend(instList,dlinkNodeAlloc(inst));

	return regIndex;
}

/**
 * Add an instruction to compute the address of a variable.
 *
 * @param instList a Dlist of instructions
 * @param varSymtab a symbol table for the variable
 * @param regSymtab a symbol table for the registers
 * @param varIndex the symbol table index for a variable
 * @return the symbol table index of the result register
 */
int emitComputeVariableAddress(DList instList, SymTable varSymtab, SymTable regSymtab, int varIndex) {
	

	int regIndex = getFreeIntegerRegisterIndex(regSymtab);
	
	int varTypeIndex = (int)SymGetFieldByIndex(varSymtab,varIndex,SYMTAB_TYPE_INDEX_FIELD);
	
	if (!isArrayType(regSymtab,varTypeIndex)) {
	
		SymPutFieldByIndex(regSymtab,regIndex,SYMTAB_INDIRECT_TYPE_FIELD,(Generic)varTypeIndex);
		char* regName = (char*)SymGetFieldByIndex(regSymtab,regIndex,SYM_NAME_FIELD);

		int offset = (int)SymGetFieldByIndex(varSymtab,varIndex,SYMTAB_OFFSET_FIELD);
		char offsetStr[10];

		snprintf(offsetStr,9,"%d",offset);

		char *inst;
		if (offset < 0)
			inst = nssave(4,"\tadd ",regName,", $fp, ",offsetStr);
		else
			inst = nssave(4,"\tadd ",regName,", $gp, ",offsetStr);
		dlinkAppend(instList,dlinkNodeAlloc(inst));
	}
	else {
		char msg[80];

		snprintf(msg,80,"Array variable %s used as a scalar",
				(char*)SymGetFieldByIndex(varSymtab,varIndex,SYM_NAME_FIELD));
		SomeLife_error(msg);
	}

	return regIndex;

}

/**
 * Compute the address of an array element and store it in a register.
 *
 * @param instList a list of instructions
 * @param varSymtab a symbol table for the variable
 * @param regSymtab a symbol table for the registers
 * @param varIndex the symbol table index of the array variable
 * @param subIndex the symbol table index of the register holding the subscript value
 * @return the symbol table index of the register holding the address of the
 * 		   array element.
 */
int emitComputeArrayAddress(DList instList, SymTable varSymtab, int varIndex, SymTable regSymtab, int subIndex) {
	
	int regIndex = getFreeIntegerRegisterIndex(regSymtab);
	int varTypeIndex = (int)SymGetFieldByIndex(varSymtab,varIndex,SYMTAB_TYPE_INDEX_FIELD);
	
	if (isArrayType(regSymtab,varTypeIndex)) {
		SymPutFieldByIndex(regSymtab,regIndex,SYMTAB_INDIRECT_TYPE_FIELD,(Generic)varTypeIndex);
		char* regName = (char*)SymGetFieldByIndex(regSymtab,regIndex,SYM_NAME_FIELD);
	
		int offset = (int)SymGetFieldByIndex(varSymtab,varIndex,SYMTAB_OFFSET_FIELD);
	
		char offsetStr[10];
	
		snprintf(offsetStr,9,"%d",offset);
	
		/* compute base address of array */
		char *inst;
		if (offset < 0)
			inst = nssave(4,"\tadd ",regName,", $fp, ",offsetStr);
		else
			inst = nssave(4,"\tadd ",regName,", $gp, ",offsetStr);
		dlinkAppend(instList,dlinkNodeAlloc(inst));

		/* compute offset base on subscript */
		char* subRegName = (char*)SymGetFieldByIndex(regSymtab,subIndex,SYM_NAME_FIELD);
		int arrayBase = getArrayBase(regSymtab, varTypeIndex);
		
		snprintf(offsetStr,9,"%d",arrayBase);
		inst = nssave(6,"\tsub ", subRegName, ", ", subRegName, ", ", offsetStr);
		dlinkAppend(instList,dlinkNodeAlloc(inst));
	
		inst = nssave(5,"\tsll ", subRegName, ", ", subRegName, ", 2");
		dlinkAppend(instList,dlinkNodeAlloc(inst));

		/* compute element address */
		inst = nssave(6,"\tadd ", regName, ", ", regName, ", ", subRegName);
		dlinkAppend(instList,dlinkNodeAlloc(inst));
	}
	else {
		char msg[80];

		snprintf(msg,80,"Scalar variable %s used as an array",
				(char*)SymGetFieldByIndex(varSymtab,varIndex,SYM_NAME_FIELD));
		SomeLife_error(msg);
	}
	
	freeIntegerRegister((int)SymGetFieldByIndex(regSymtab,subIndex,SYMTAB_REGISTER_INDEX_FIELD));

	return regIndex;

}

/**
 * Add an instruction to load a variable from memory.
 *
 * @param instList a Dlist of instructions
 * @param symtab a symbol table
 * @param regIndex the symbol table index for the address of a variable
 * @return the symbol table index of the result register
 */
int emitLoadVariable(DList instList, SymTable symtab, int regIndex) {

	int newRegIndex;
	int memoryType = getMemoryTypeByIndex(symtab,regIndex);
	
	if (memoryType == INTEGER_TYPE)
		newRegIndex = getFreeIntegerRegisterIndex(symtab);
	else
		newRegIndex = getFreeFloatRegisterIndex(symtab);

	char* newRegName = (char*)SymGetFieldByIndex(symtab,newRegIndex,SYM_NAME_FIELD);

	char* regName = (char*)SymGetFieldByIndex(symtab,regIndex,SYM_NAME_FIELD);

	char *inst;
	
	if (memoryType == INTEGER_TYPE)
		inst = nssave(5,"\tlw ",newRegName,", 0(",regName,")");
	else
		inst = nssave(5,"\tl.s ",newRegName,", 0(",regName,")");
	
	dlinkAppend(instList,dlinkNodeAlloc(inst));

	freeIntegerRegister((int)SymGetFieldByIndex(symtab,regIndex,SYMTAB_REGISTER_INDEX_FIELD));

	return newRegIndex;

}

/**
 * Add an instruction to load an integer constant
 *
 * @param instList a Dlist of instructions
 * @param symtab a symbol table
 * @param intIndex the symbol table index for an integer constant
 * @return the symbol table index of the result register
 */
int emitLoadIntegerConstant(DList instList, SymTable symtab, int intIndex) {
	int regIndex = getFreeIntegerRegisterIndex(symtab);
	char* regName = (char*)SymGetFieldByIndex(symtab,regIndex,SYM_NAME_FIELD);
	
	char *intName = SymGetFieldByIndex(symtab,intIndex,SYM_NAME_FIELD);
	
	char *inst = nssave(4,"\tli ",regName, ", ", intName);
	
	DNode node = dlinkNodeAlloc(inst);
	
	dlinkAppend(instList,node);
	
	return regIndex;
			                
}
/**
 * Create a data declaration for a floating-point constant
 *
 * @param dataList a list of declarations for the static data area
 * @param symtab a symbol table
 * @param floatIndex the symbol table index of a floating-point constant
 * @return the label in the static data area for the floating-point constant
 */
static char* makeFloatDeclaration(DList dataList, SymTable symtab, int floatIndex) {
	static int floatNum = 0;
	char* fltValue = (char*)SymGetFieldByIndex(symtab,floatIndex,SYM_NAME_FIELD);
	char* fltLabel = (char*)malloc(sizeof(char)*15);

	snprintf(fltLabel,14,".float%d",floatNum++);

	char* decl = nssave(3,fltLabel,": .float ",fltValue);
	dlinkAppend(dataList,dlinkNodeAlloc(decl));

	return fltLabel;
}

/**
 * Emit an instruction to load a floating-point constant from the static data area.
 *
 * @param instList a list of instructions
 * @param dataList a list of declarations for the static data area
 * @param symtab a symbol table
 * @param fltIndex the symbol table index of the floating-point constant to load.
 * @return
 */
int emitLoadFloatConstant(DList instList, DList dataList, SymTable symtab, int fltIndex) {
	char *fltLabel = makeFloatDeclaration(dataList,symtab,fltIndex);

	int regIndex = getFreeFloatRegisterIndex(symtab);
	char* regName = (char*)SymGetFieldByIndex(symtab,regIndex,SYM_NAME_FIELD);

	char* inst = nssave(4,"\tl.s ",regName, ", ",fltLabel);
	dlinkAppend(instList,dlinkNodeAlloc(inst));

	free(fltLabel);

	return regIndex;
}

/**
 * Add a .asciiz declaration for a string constant.
 *
 * @param dataList a DList of data declarations
 * @param symtab a symbol table
 * @param stringIndex the symbol table index of a string constant
 * @return
 */
static char* makeDataDeclaration(DList dataList, SymTable symtab, int stringIndex) {
	static int stringNum = 0;
	char* string = (char*)SymGetFieldByIndex(symtab,stringIndex,SYM_NAME_FIELD);
	char* strLabel = (char*)malloc(sizeof(char)*15);

	snprintf(strLabel,14,".string%d",stringNum++);

	char* strChars = substr(string,1,strlen(string)-2); /**< the string constant w/o quotes */
	char* decl = nssave(4,strLabel,": .asciiz \"",strChars,"\"");
	dlinkAppend(dataList,dlinkNodeAlloc(decl));

	free(strChars);

	return strLabel;
}


/**
 * Add an instruction to load the address of a string constant
 *
 * @param instList a Dlist of instructions
 * @param dataList a Dlist of data declarations
 * @param symtab a symbol table
 * @param stringIndex the symbol table index for a string constant
 * @return the symbol table index of the result register
 */
int emitLoadStringConstantAddress(DList instList, DList dataList, SymTable symtab, int stringIndex) {
	char *strLabel = makeDataDeclaration(dataList,symtab,stringIndex);

	int regIndex = getFreeIntegerRegisterIndex(symtab);
	char* regName = (char*)SymGetFieldByIndex(symtab,regIndex,SYM_NAME_FIELD);

	char* inst = nssave(4,"\tla ",regName, ", ",strLabel);
	dlinkAppend(instList,dlinkNodeAlloc(inst));

	free(strLabel);

	return regIndex;
}

static int convertArrayType(int symIndex, int typeIndex, AddIdStructPtr data) {
	char *typeName = (char *)SymGetFieldByIndex(data->typeSymtab,typeIndex,SYM_NAME_FIELD);
	int voidIndex = find(typeName,SYMTAB_VOID_TYPE_STRING);

	if (voidIndex != -1) {
		char *newTypeName;
		int elementSize;
		if (getTypeByIndex(data->typeSymtab,data->typeIndex) == INTEGER_TYPE) {
			newTypeName = nssave(2,SYMTAB_INTEGER_TYPE_STRING,strtail(typeName,voidIndex + strlen(SYMTAB_VOID_TYPE_STRING)));
			elementSize = INTEGER_SIZE;
		}
		else {
			newTypeName = nssave(2,SYMTAB_FLOAT_TYPE_STRING,strtail(typeName,voidIndex + strlen(SYMTAB_VOID_TYPE_STRING)));
			elementSize = FLOAT_SIZE;
		}
                		
                int newTypeIndex = SymIndex(data->typeSymtab,newTypeName);
               	SymPutFieldByIndex(data->typeSymtab,newTypeIndex,SYMTAB_BASIC_TYPE_FIELD,(Generic)data->typeIndex);
		int newSize = ((int)SymGetFieldByIndex(data->typeSymtab,typeIndex,SYMTAB_SIZE_FIELD) / VOID_SIZE) * elementSize;
               	SymPutFieldByIndex(data->typeSymtab,newTypeIndex,SYMTAB_SIZE_FIELD,(Generic)newSize);
		SymPutFieldByIndex(data->idSymtab,symIndex,SYMTAB_TYPE_INDEX_FIELD,(Generic)newTypeIndex);

		return newTypeIndex;
 	}
	else
		return typeIndex;

}

/**
 * Add an identifier to the symbol table and store its offset in the activation record.
 * This function is called by dlinkApply1.
 *
 * @param node a node on a linked list containing the symbol table index of a variable
 * 		  delcared in a program
 * @param data a structure containing the symbol table index of the type of the variable,
 * 		  the symbol table, and the current offset in the activation record.
 */
void addIdToSymtab(DNode node, AddIdStructPtr data) {

	int symIndex = (int)dlinkNodeAtom(node);
	int typeIndex = (int)SymGetFieldByIndex(data->idSymtab,symIndex,SYMTAB_TYPE_INDEX_FIELD);
	
	if (typeIndex == -1) {
		SymPutFieldByIndex(data->idSymtab,symIndex,SYMTAB_TYPE_INDEX_FIELD,(Generic)data->typeIndex);
		typeIndex = data->typeIndex;
	}
	else
		typeIndex = convertArrayType(symIndex,typeIndex,data);	

	/*if (isArrayType(data->typeSymtab,typeIndex) && data->offsetDirection > 0) { // globally allocated array
		int basicType = (int)SymGetFieldByIndex(data->typeSymtab,typeIndex,SYMTAB_BASIC_TYPE_FIELD);
		int size = (int)SymGetFieldByIndex(data->typeSymtab,basicType,SYMTAB_SIZE_FIELD);
		SymPutFieldByIndex(data->idSymtab,symIndex,SYMTAB_OFFSET_FIELD,
				   (Generic)(data->offset+size*data->offsetDirection));
		size = (int)SymGetFieldByIndex(data->typeSymtab,typeIndex,SYMTAB_SIZE_FIELD);
		data->offset += size*data->offsetDirection;
	}
	else {
		int size = (int)SymGetFieldByIndex(data->typeSymtab,typeIndex,SYMTAB_SIZE_FIELD);
		data->offset += size*data->offsetDirection;
		SymPutFieldByIndex(data->idSymtab,symIndex,SYMTAB_OFFSET_FIELD,(Generic)data->offset);
		}*/
	int size = (int)SymGetFieldByIndex(data->typeSymtab,typeIndex,SYMTAB_SIZE_FIELD);
	int off = (data->offsetDirection==1)? 0 : -size;

	SymPutFieldByIndex(data->idSymtab,symIndex,SYMTAB_OFFSET_FIELD,(Generic)(data->offset+off));
	data->offset += size*data->offsetDirection;

}

