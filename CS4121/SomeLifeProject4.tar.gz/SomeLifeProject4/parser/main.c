/*
 * main.c
 *
 *  Created on: Jan 25, 2011
 *      Author: carr
 */

#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <strings.h>
#include <string.h>
#include <util/general.h>
#include <util/symtab.h>
#include <util/symtab_stack.h>
#include <util/dlink.h>
#include <util/string_utils.h>
#include <codegen/codegen.h>
#include <codegen/symfields.h>
#include "SomeLifeParserHeader.h"
#include "SomeLifeParser.h"

void* slParser;
SymTable symtab;
DList instList;
DList procInstList;
DList mainInstList;
DList dataList;
DNode endOfPreviousStatement;
int integerTypeId;
int floatTypeId;
int offsetDirection = 1;
int functionOffset;
int globalOffset = 0;
char *fileName;
SymtabStack symtabStack;
int functionType;

void SomeLife_error(char *s)
{
  fprintf(stderr,"%s: line %d: %s\n",fileName,SomeLife_lineno,s);
}

int SomeLife_wrap() {
	return 1;
}

SymTable addSymTable() {

	SymTable symtab = beginScope(symtabStack);

	SymInitField(symtab,SYMTAB_TYPE_INDEX_FIELD,(Generic)-1,NULL);
	SymInitField(symtab,SYMTAB_SIZE_FIELD,(Generic)-1,NULL);
	SymInitField(symtab,SYMTAB_OFFSET_FIELD,(Generic)-1,NULL);
	SymInitField(symtab,SYMTAB_REGISTER_INDEX_FIELD,(Generic)-1,NULL);
	SymInitField(symtab,SYMTAB_BASIC_TYPE_FIELD,(Generic)-1,NULL);
	SymInitField(symtab,SYMTAB_INDIRECT_TYPE_FIELD,(Generic)-1,NULL);

	return symtab;
}

void deleteSymTable() {

    SymTable symtab = endScope(symtabStack);

    SymKillField(symtab,SYMTAB_TYPE_INDEX_FIELD);
    SymKillField(symtab,SYMTAB_SIZE_FIELD);
    SymKillField(symtab,SYMTAB_OFFSET_FIELD);
    SymKillField(symtab,SYMTAB_REGISTER_INDEX_FIELD);
    SymKillField(symtab,SYMTAB_BASIC_TYPE_FIELD);
    SymKillField(symtab,SYMTAB_INDIRECT_TYPE_FIELD);
    SymKill(symtab);

}

static void initialize(char* inputFileName) {

	stdin = freopen(inputFileName,"r",stdin);
        if (stdin == NULL) {
          fprintf(stderr,"Error: Could not open file %s\n",inputFileName);
          exit(-1);
        }

	char* dotChar = rindex(inputFileName,'.');
	int endIndex = strlen(inputFileName) - strlen(dotChar);
	char *outputFileName = nssave(2,substr(inputFileName,0,endIndex),".s");
	stdout = freopen(outputFileName,"w",stdout);
        if (stdout == NULL) {
          fprintf(stderr,"Error: Could not open file %s\n",outputFileName);
          exit(-1);
        }

	symtabStack = symtabStackInit();
	SymTable symtab = addSymTable();
        slParser = SomeLife_ParseAlloc( malloc );
	
	int intIndex = SymIndex(symtab,SYMTAB_INTEGER_TYPE_STRING);
	int floatIndex = SymIndex(symtab,SYMTAB_FLOAT_TYPE_STRING);
	int errorIndex = SymIndex(symtab,SYMTAB_ERROR_TYPE_STRING);
	int voidIndex = SymIndex(symtab,SYMTAB_VOID_TYPE_STRING);
	
	SymPutFieldByIndex(symtab,intIndex,SYMTAB_SIZE_FIELD,(Generic)INTEGER_SIZE);
	SymPutFieldByIndex(symtab,floatIndex,SYMTAB_SIZE_FIELD,(Generic)FLOAT_SIZE);
	SymPutFieldByIndex(symtab,errorIndex,SYMTAB_SIZE_FIELD,(Generic)0);
	SymPutFieldByIndex(symtab,voidIndex,SYMTAB_SIZE_FIELD,(Generic)0);
	
	SymPutFieldByIndex(symtab,intIndex,SYMTAB_BASIC_TYPE_FIELD,(Generic)INTEGER_TYPE);
	SymPutFieldByIndex(symtab,floatIndex,SYMTAB_BASIC_TYPE_FIELD,(Generic)FLOAT_TYPE);
	SymPutFieldByIndex(symtab,errorIndex,SYMTAB_BASIC_TYPE_FIELD,(Generic)ERROR_TYPE);
	SymPutFieldByIndex(symtab,voidIndex,SYMTAB_BASIC_TYPE_FIELD,(Generic)VOID_TYPE);
	
	initRegisters();
	
	procInstList = dlinkListAlloc(NULL);
	mainInstList = dlinkListAlloc(NULL);
	dataList = dlinkListAlloc(NULL);

}

static void finalize() {

    fclose(stdin);
    
    deleteSymTable();
 
    cleanupRegisters();
    
    dlinkFreeNodesAndAtoms(procInstList);
    dlinkFreeNodesAndAtoms(mainInstList);
    dlinkFreeNodesAndAtoms(dataList);

}

int main(int argc, char** argv)

{
    fileName = argv[1];
    initialize(fileName);

    SomeLife_lex();

    SomeLife_Parse(slParser, 0, (TokenAttributePtr)NULL);

    finalize();

    return 0;
}
/******************END OF C ROUTINES**********************/
